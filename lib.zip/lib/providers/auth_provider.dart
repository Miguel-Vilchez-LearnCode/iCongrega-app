import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:icongrega/core/errors/api_exception.dart';
import 'package:icongrega/domain/models/user.dart';
import 'package:icongrega/domain/repositories/auth_repository.dart';
import 'package:icongrega/domain/responses/login_response.dart';

class AuthProvider with ChangeNotifier {

  final AuthRepository _authRepository;

  AuthProvider(this._authRepository);

  bool _isLoading = false;
  String _emailForVerification = '';
  String _errorMessage = '';
  LoginResponse? _loginResponse;
  String? pendingEmail;
  String? verificationError;

  bool get isLoading => _isLoading;
  String get emailForVerification => _emailForVerification;
  String get errorMessage => _errorMessage;
  LoginResponse? get loginResponse => _loginResponse;
  User? get currentUser => _loginResponse?.user;
  bool get isAuthenticated => _loginResponse != null;

  Future<void> login(String email, String password) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      _loginResponse = await _authRepository.login(email, password);
      if (kDebugMode) {
        debugPrint('Login exitoso: ${_loginResponse!.message}');
        debugPrint('Token: ${_loginResponse!.token}');
        debugPrint('Usuario: ${_loginResponse!.user.fullName}');
      }
    } on ApiException catch (e) {
      _errorMessage = e.message;
      if (kDebugMode) {
        debugPrint('Error en login: $e');
      }
    } catch (e) {
      _errorMessage = 'Error inesperado. Intenta nuevamente.';
      if (kDebugMode) {
        debugPrint('Error inesperado en login: $e');
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> registerUser(Map<String, dynamic> body) async{
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _authRepository.register(body);

      _emailForVerification = response["email"];
      return true;

    } on ApiException catch (e) {
      _errorMessage = e.message;
      if (kDebugMode) {
        debugPrint('Error de registro: $e');
      }
      return false;

    } catch (e) {
      _errorMessage = 'Error inesperado. Intenta nuevamente.';
      if (kDebugMode) {
        debugPrint('Error inesperado al registrar usuario: $e');
      }
      return false;
      
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> verifyEmailCode(String code) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _authRepository.verifyEmail(pendingEmail!, code);

      // Cargar usuario y token en el provider
      user = User.fromJson(response["user"]);
      token = "${response["token_type"]} ${response["token"]}";

      // Guardar token (si usas shared prefs o secure storage)
      await storage.write(key: "token", value: token);

      _isLoading = false;
      notifyListeners();
      return true;

    } catch (e) {
      verificationError = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<String?> getStoredToken() {
    return _authRepository.accessToken;
  }

  Future<void> restoreSession() async {
    try {
      final storedSession = await _authRepository.loadStoredSession();
      _loginResponse = storedSession;
    } catch (e) {
      if (kDebugMode) {
        debugPrint('Error restaurando sesión: $e');
      }
    } finally {
      notifyListeners();
    }
  }

  Future<void> logout() async {
    await _authRepository.logout();
    _loginResponse = null;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = '';
    notifyListeners();
  }

}