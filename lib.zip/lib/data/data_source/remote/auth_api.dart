import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:icongrega/core/errors/api_exception.dart';
import 'package:icongrega/data/helpers/http.dart';
import 'package:icongrega/data/helpers/http_method.dart';
import 'package:icongrega/domain/responses/login_response.dart';

class AuthAPI {
  final Http _http;
  final String version = dotenv.env['API_VERSION'] ?? 'v1';

  AuthAPI(this._http);

  Future<LoginResponse> login(String email, String password) async {
    final result = await _http.request<Map<String, dynamic>>(
      '/api/$version/auth/login',
      method: HttpMethod.post,
      body: {'email': email, 'password': password},
      parser: (data) => Map<String, dynamic>.from(data as Map),
    );

    if (kDebugMode) {
      debugPrint('Status Code: ${result.statusCode}');
      debugPrint('Response Body: ${result.body}');
    }

    if (result.error != null) {
      final message = _extractErrorMessage(result.error?.data) ??
          'Error en el servidor: ${result.statusCode}';
      throw ApiException(message, statusCode: result.statusCode);
    }

    final data = result.data;
    if (data == null) {
      throw ApiException(
        'Respuesta vacía del servidor',
        statusCode: result.statusCode,
      );
    }

    return LoginResponse.fromJson(data);
  }

  String? _extractErrorMessage(dynamic errorData) {
    if (errorData is Map<String, dynamic>) {
      return errorData['message'] as String?;
    }
    if (errorData is String) {
      return errorData;
    }
    return null;
  }

  Future<Map<String, dynamic>> register(Map<String, dynamic> payload) async{
    final result = await _http.request<Map<String, dynamic>>(
      '/api/$version/auth/register',
      method: HttpMethod.post,
      body: payload,
    );

    if (kDebugMode) {
      debugPrint('Status Code: ${result.statusCode}');
      debugPrint('Response Body: ${result.body}');
    }

    if (result.error != null) {
      final message = _extractErrorMessage(result.error?.data) ??
          'Error en el servidor: ${result.statusCode}';
      throw ApiException(message, statusCode: result.statusCode);
    }
    
    return result.data!;
  }

  Future<Map<String,dynamic>> verifyEmail({
    required String email, 
    required String code
  }) async {
    final result = await _http.request<Map<String,dynamic>>(
      '/api/$version/auth/verify-email',
      method: HttpMethod.post,
      body: {
        "email": email,
        "code": code,
      },
    );

    if (kDebugMode) {
      debugPrint('Status Code: ${result.statusCode}');
      debugPrint('Response Body: ${result.body}');
    }

    if (result.error != null) {
      final message = _extractErrorMessage(result.error?.data) ??
          'Error en el servidor: ${result.statusCode}';
      throw ApiException(message, statusCode: result.statusCode);
    }
    
    return result.data!;
  }

}
